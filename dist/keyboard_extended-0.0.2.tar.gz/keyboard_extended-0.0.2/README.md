# keyboard_extended
Extension for the keyboard package

Class:
- Key
Funcitons:
- getKey  
  use this instead of creating a new instance to avoid deleting bindings
- unbind_all_hotkeys