from .KeyboardClass import Key, get_Key, getKey, unbind_all_hotkeys
from keyboard import *

__version__ = "0.0.2"
